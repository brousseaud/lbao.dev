<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
  <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri();?>/dist/styles/foundation-icons.css">
<link href='https://fonts.googleapis.com/css?family=Titillium+Web:700italic,700|Open+Sans:300,700,300italic,700italic' rel='stylesheet' type='text/css'></head>
